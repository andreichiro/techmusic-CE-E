﻿# *TechMusic*

## Documentos
* Documentação Hardware
* Documentação Interfaces/Integração comunicação
* Documentação Software
* Desenvolvimento
* Entrega Final

Documentações que podem compor as entregas:
* [Documento de Visão do Projeto](1-visao/)
* [Casos de Uso](2-casos-de-uso/)
* Mapas de Navegação
* Arquitetura
* Detalhamento dos Componentes

