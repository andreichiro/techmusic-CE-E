﻿slides, parafusos, nozes, gabinete, resistor, leds, shifters, botões, Arduino Uno, multiplexadores, rotativos

